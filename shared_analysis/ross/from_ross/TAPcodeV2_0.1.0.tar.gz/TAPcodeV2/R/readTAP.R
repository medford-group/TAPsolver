#' Read Excel TDMS
#'
#' Reads in an Excel .xlsx of the original TDMS file.  This requires that data has been previously converted to .xlsx by the tdms addon in Excel.  This is the function that will be called when an user uploads data.
#'
#' This function is based on R package rio.
#'
#' @param dataPath This is a string path to an .xlsx file.
#' @return A collection of TAP objects that describe the experiment performed in the reactor.
#' @examples
#'
#' path = file.choose()
#' # note this requires to load a file that was originally TDMS and has since been converted to .xlsx.
#'
#' readTAP(path)
#' @export readTAP

readTAP = function(dataPath){

  if(substr(dataPath,(nchar(dataPath)-3), nchar(dataPath)) == "tdms"){
    result = list()
    sheetPos = 3
    currentName = NULL
    reactorDF = data.frame("reactorParameters" = c("inertZone1Length", "inertZone2Length",
                                                   "catalystBedLength", "crossSectionalArea",
                                                   "catalystWeight", "bedPorosity",
                                                   "molPerM0Inert", "pumpProbeSpacing"),
                           "value" = c(0.02, 0.02, 0.00075, 1.14009E-05, 1, 0.4, 1.63E-09, 0),
                           "unit" = c("m", "m", "m", "m^2", "g", "none", "mol", "s"))
    reactorParams = as.list(reactorDF$value)
    names(reactorParams) = reactorDF$reactorParameters
    result[["reactor"]] = list("reactorParams" = reactorParams,"reactorDF" = reactorDF, "scriptList" = "Start")

    # new Struct
    #result[["parameters"]] = list("reactor" = NULL, "experiment" = NULL, "simulation" = NULL)

    # Experiment
    # num pulses
    # num timepoints
    # min time
    # max time
    # timeVector
    # pumpProbe spacing

    library(reticulate)
    #use_python("/opt/anaconda/bin/python3.7")
    #use_virtualenv("r-reticulate")
    nptdms = reticulate::import("nptdms")
    tempFile = nptdms$TdmsFile(dataPath)
    groupNames = nptdms$TdmsFile$groups(tempFile)

    for(i in sheetPos:length(groupNames)){
      attempt = tempFile$object(groupNames[i])
      attempt = attempt$as_dataframe()
      #currentName[resultPos] = paste0(unlist(tempDF$Value[1]), "AMU")

      currentList = list()

      # Assign AMU
      currentList$AMU = as.numeric(unlist(attempt$Value[1],F,F))
      currentList$time = attempt$Time
      currentList$time[length(currentList$time)] = currentList$time[2] + currentList$time[length(currentList$time) - 1]
      currentList$time = currentList$time[-1]
      currentList$temperature = as.numeric(unlist(attempt[1,],F,F)[-(1:3)])
      currentList$pulses = attempt[-1,-(1:3)]

      attemptWithName = c(paste0("AMU",attempt$Value[1]), unlist(attempt$Value,F,F)[1:14])
      tempOptions = as.list(attemptWithName)
      names(tempOptions) = c("Name",'AMU','Gain','Pulse Spacing','Collection Time','Delay Time A','Delay Time B','Delay Time C','Delay Time D','Pulse Width A','Pulse Width B','Pulse Width C','Pulse Width D','Data Samples','Total Pulses')
      tempOptions[["baselineStart"]] = min(currentList$time)
      tempOptions[["baselineEnd"]] = max(currentList$time)
      tempOptions[["baselineType"]] = "mean"
      tempOptions[["timeStart"]] = min(currentList$time)
      tempOptions[["timeEnd"]] = max(currentList$time)
      tempOptions[["inert"]] = paste0("AMU",attempt$Value[1])
      tempOptions[["isProduct"]] = NA
      tempOptions[["calibrationCoef"]] = 1
      tempOptions[["diffusionCoef"]] = 0
      tempOptions[["savGolSmoothing"]] = 0
      tempOptions[["yProcSmoothing"]] = 0
      tempOptions[["waveSmoothing"]] = 0
      tempOptions[[2]] = as.numeric(tempOptions[[2]])
      listOfNothing = as.list(rep(NA, dim(attempt)[1] - length(tempOptions)))
      names(listOfNothing) = rep("", dim(attempt)[1] - length(tempOptions))
      tempOptions = c(tempOptions, listOfNothing)
      currentList$options = tempOptions

      result[[tempOptions$Name]] = currentList
    }
  }else{
    result = list()
    sheetPos = 4
    currentName = NULL

    reactorParams = rio::import(dataPath, which = 1)
    tempList = list( "reactorParams" = as.list(reactorParams$value), "reactorDF" = reactorParams)
    names(tempList$reactorParams) = reactorParams$reactorParameters
    tempList$scriptList = rio::import(dataPath, which = 2)
    result[["reactor"]] = tempList

    while(sheetPos != 0){
      attempt = try(rio::import(dataPath, which = sheetPos), silent = T)
      if(is.data.frame(attempt)){

        #### options for different items
        tempOptions = as.list(attempt$Value)
        names(tempOptions) = c(attempt$Item[1:27], rep("",(length(attempt$Item) - 27)))
        nullPositions = which(attempt$Value == "NA")
        stringOptions = c(1,18,21)
        numericPosition = c(1:27)[-c(stringOptions,nullPositions)]
        for(i in numericPosition){
          tempOptions[[i]] = as.numeric(tempOptions[[i]])
        }
        for(i in nullPositions){
          tempOptions[[i]] = NA
        }
        currentList = list()

        # Assign Time values
        currentList$time = attempt$Time
        timeLen = length(currentList$time)
        currentList$time[timeLen] = currentList$time[2] + currentList$time[timeLen - 1]
        currentList$time = currentList$time[-1]
        currentList$temperature = as.numeric(unlist(attempt[1,],F,F)[-(1:3)])
        currentList$pulses = attempt[-1,-(1:3)]
        currentList$options = tempOptions

        ##### return result
        result[[tempOptions$Name]] = currentList
        sheetPos = sheetPos + 1

      }else{
        sheetPos = 0
      }
    }
  }

  # correction for different number of pulses within experiment
  numPulses = rep(0,length(result))[-1]
  for(i in 2:length(result)){
    numPulses[i-1] = dim(result[[i]]$pulses)[2]
  }
  for(i in 2:length(result)){
    if(numPulses[i-1] != min(numPulses)){
      result[[i]]$pulses = result[[i]]$pulses[,1:min(numPulses)]
      result[[i]]$temperature = result[[i]]$temperature[1:min(numPulses)]
    }
  }


  return(result)
}
