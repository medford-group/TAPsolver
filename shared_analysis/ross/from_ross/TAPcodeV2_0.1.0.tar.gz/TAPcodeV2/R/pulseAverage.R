#' Pulse Average
#'
#' Pulse Average
#'
#' blah
#'
#' @param TAPexperiment A set of pre-processing parameters based on the Y-Procedure
#' @param gasName Blah
#' @return Blah
#' @examples
#' data("pulseData")
#'
#'
#'@export pulseAverage
pulseAverage = function(TAPexperiment, gasName, pulseRange = NULL){

  for(i in 1:length(gasName)){
    TAPobj = TAPexperiment[[gasName[i]]]
    if(is.null(TAPobj$moments)){
      TAPexperiment = moments(TAPexperiment, gasName[i])
      TAPobj = TAPexperiment[[gasName[i]]]
    }

    if(is.null(pulseRange))
      pulseRange = 1:dim(TAPobj$pulses)


    TAPobj$pulses = data.frame( "avg" = apply(TAPobj$pulses[,pulseRange], 1, mean))
    TAPobj$temperature =  mean(TAPobj$temperature[pulseRange])
    TAPobj$moments = as.data.frame(t(apply(TAPobj$moments[pulseRange, ], 2, mean )))

    TAPobj$options$Name = paste0(gasName[i], "avg")
    TAPexperiment[[TAPobj$options$Name]] = TAPobj
  }

  return(TAPexperiment)
}








