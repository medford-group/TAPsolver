#' Inert Graham Calculation
#'
#' Scale inert flux by Graham's Law
#'
#' This funciton is for manipulation of the inert flux to appear as if it has a different mass.  This allows the inert gas to behave as the reactant gas
#' without any interaction on the catalyst.  This function scales the magnitude and time by the square root of the ratio of masses.  For example, if the
#' inert gas was Argon (AMU of 40) and the reactant was Oxygen (AMU 32), the inert will be scaled by \eqn{\sqrt{40/32}}.
#'
#'
#' @param TAPobj The inert gas flux
#' @param newMass Transformed mass
#' @return A matrix or vector of transformed inert flux
#'
#' @examples
#' data("pulseData")
#' inert = pulseData$`40AMU`$pulses
#' TAPobj$time = pulseData$`40AMU`$time
#' grahamsConstant = sqrt(40/32)
#'
#' inertGraham(inert, TAPobj$time, grahamsConstant)
#'
#'
#'
#' @export inertGraham
#'
inertGraham = function(TAPexperiment, gasName, newMass){

  for(i in 1:length(gasName)){
    TAPobj = TAPexperiment[[gasName[i]]]
    minTime = min(TAPobj$time)
    maxTime = max(TAPobj$time)
    grahamsConstant = sqrt(TAPobj$options$AMU / newMass)
    roundPt = round(length(TAPobj$time) / grahamsConstant)

    for(j in 1:dim(TAPobj$pulses)[2]){
      tempFun = approxfun(TAPobj$time, TAPobj$pulses[,j])

      if(grahamsConstant >= 1){
        TAPobj$pulses[,j] = grahamsConstant * c(tempFun( seq(minTime, maxTime,length.out = roundPt) ), rep(tempFun(maxTime), length(TAPobj$time) - roundPt))
      }else{
        TAPobj$pulses[,j] = tempFun( seq(minTime, maxTime,length.out = length(TAPobj$time)))  *  grahamsConstant
      }
    }

    TAPobj$options$Name = paste0(gasName, "to", newMass)
    TAPexperiment[[TAPobj$options$Name]] = TAPobj
  }
  return(TAPexperiment)
}
