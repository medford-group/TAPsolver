#' Gas Concentration
#'
#' Optimization of the Y-Procedure Smoothing value
#'
#' blah
#'
#' @param TAPobj A set of pre-processing parameters based on the Y-Procedure
#' @param method Blah
#' @return Blah
#' @examples
#' data("pulseData")
#'
#'
#'@export gasCon

gasCon = function(TAPexperiment, gasName, method = "y"){

  for(i in 1:length(gasName)){
    if(is.null(TAPexperiment[[gasName[i]]]$reactorLength)){
      TAPexperiment = initYproc(TAPexperiment, gasName[i], method)
    }
    TAPobj = TAPexperiment[[gasName[i]]]

    if(method == "y"){
      for(j in 1:dim(TAPobj$pulses)[2]){
        tempPulse = TAPobj$pulses[TAPobj$timeRange, j]
        result = Re(fft(fft(tempPulse) * TAPobj$gasScalar, inverse = T)) * TAPobj$gasConScalar[j]

        if(length(result) != dim(TAPobj$pulses)[1]){
          trailingMedian = rep(median(result[round(.9*length(result)):length(result)]), dim(TAPobj$pulses)[1] - length(result))
          result = c(result, trailingMedian)
        }
        TAPobj$pulses[, j] = result
      }
    }else{
      gasScalar = 1 - TAPobj$inertZoneRatio^2 / 6
      basicShape =  3 / 2

      for(j in 1:dim(TAPobj$pulses)[2]){
        tempPulse = TAPobj$pulses[TAPobj$timeRange, j] / TAPobj$moments$M0[j]

        tempMean = mean(tempPulse * TAPobj$currentTime * TAPobj$options$timeEnd) * pi / 4
        if(mean(tempPulse * TAPobj$currentTime * TAPobj$options$timeEnd) < 0){
          # use median if mean is below zero due to noise
          tempMean = TAPobj$currentTime[TAPcodeV2::robustMode(tempPulse)] * 3 * pi / 4
        }
        pulseGamma = pgamma(TAPobj$currentTime, shape = basicShape, scale = tempMean * 2/3)
        gasGamma = pgamma(TAPobj$currentTime, shape = gasScalar * basicShape, scale = tempMean * 2/3)
        gasRatio = gasGamma / pulseGamma

        result = c(0, diff(cumsum(tempPulse) * gasRatio)) * TAPobj$moments$M0[j] * TAPobj$gasConScalar[j]
        result[is.na(result)] = 0

        if(length(result) != dim(TAPobj$pulses)[1]){
          trailingMedian = rep(median(result[round(.9*length(result)):length(result)]), dim(TAPobj$pulses)[1] - length(result))
          result = c(result, trailingMedian)
        }
        TAPobj$pulses[, j] = result
      }
    }
    TAPobj$options$Name = paste0(gasName[i], "gasCon")
    TAPexperiment[[TAPobj$options$Name]] = TAPobj
  }

  return(TAPexperiment)
}








