#' Baseline correction on a TAP object
#'
#' Correct the baseline of a pulse towards zero
#'
#' The TAP pulse mass spec results may sometimes not reach zero appropriately when no product is produced or when all the reactant is consumed.
#' In this case, it is nessecary to perform a baseline correction of the respective pulse.  This is slightly different from typical baseline correction because it is only necessary
#' to shift the pulse vertically such that the baseline portion is at zero.  This method requires a user to know at what time segment the baseline is not changing, i.e., the slope of the pulse
#' remains constant or flat.  Once baseline has been determined, this function will shift the whole pulse vertically by subtracting a choice of either the min or mean of the baseline time segment.
#'
#'
#' @param TAPobj A vector of pulse values
#' @return The baseline corrected values of \code{TAPobj}
#' @examples
#' data("pulseData")
#' TAPobj = pulseData$`32AMU`
#' bc = baselineCorrect(TAPobj)
#'
#' @export baselineCorrect
#'

baselineCorrect = function(TAPexperiment, gasName){

  for(i in 1:length(gasName)){
    TAPobj = TAPexperiment[[gasName[i]]]
    if(TAPobj$options$baselineType == "none")
      next
    baselineMinPos = which.min(abs(TAPobj$time - TAPobj$options$baselineStart))
    baselineMaxPos = which.min(abs(TAPobj$time - TAPobj$options$baselineEnd))

    tempMeans = apply(TAPobj$pulses[baselineMinPos:baselineMaxPos, ], 2, TAPobj$options$baselineType)
    TAPobj$pulses = sweep(TAPobj$pulses, 2, tempMeans)
    TAPexperiment[[TAPobj$options$Name]] = TAPobj
  }
  return(TAPexperiment)
}

