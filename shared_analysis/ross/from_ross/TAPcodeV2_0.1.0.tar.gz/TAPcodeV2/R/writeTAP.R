#' Write Excel TAP file
#'
#' Write an Excel .xlsx of the original TDMS file.
#'
#' This function is based on R package rio.
#'
#' @param dataPath This is a string path to an .xlsx file.
#' @return A collection of TAP objects that describe the experiment performed in the reactor.
#' @examples
#'
#'
#' readTAP(path)
#' @export writeTAP

writeTAP = function(TAPexperiment, dataPath){
  sheetList = list()

  # reactorParams is manipulated and needs to be adjusted in the DF
  TAPexperiment$reactor$reactorDF$value = unlist(TAPexperiment$reactor$reactorParams,F,F)
  sheetList[["reactor"]] = (TAPexperiment[["reactor"]])$reactorDF
  sheetList[["secondaryInfo"]] = TAPexperiment[["reactor"]]$scriptList
  sheetList[["metaData"]] = ""

  TAPnames = names(TAPexperiment)
  for(i in 1:length(TAPexperiment)){
    if(TAPnames[i] == "reactor")
      next
    TAPobj = TAPexperiment[[i]]
    pulseNames = names(TAPobj$pulses)
    tempDF = rbind(TAPobj$temperature, TAPobj$pulses)
    tempDF = cbind( names(TAPobj$options), unlist(TAPobj$options,F,F), c(0,TAPobj$time), tempDF)
    names(tempDF) = c("Item", "Value", "Time", pulseNames)
    sheetList[[TAPnames[i]]] = tempDF
  }
  rio::export(sheetList, dataPath)

}

