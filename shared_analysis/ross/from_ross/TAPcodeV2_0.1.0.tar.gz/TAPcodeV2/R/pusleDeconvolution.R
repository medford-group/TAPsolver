#' Pulse Deconvolution
#'
#' Pulse Deconvolution
#'
#' blah
#'
#' @param TAPexperiment A set of collected gas species.
#' @param gasName Name of the Gas to be processed.
#' @return Blah
#' @examples
#' data("pulseData")
#'
#'
#'@export pulseDeconvolution
pulseDeconvolution = function(TAPexperiment, gasName){

  for(i in 1:length(gasName)){
    TAPobj = TAPexperiment[[gasName[i]]]

    if(is.null(TAPexperiment$reactor$reactorParams$pumpProbeSpacing))
      stop("Must include a time for the start of the second pulse.")

    pulseDelayPosition = 1:(which.min(abs(TAPobj$time - TAPexperiment$reactor$reactorParams$pumpProbeSpacing)))

    preTAPobj = TAPobj
    preTAPobj$pulses = preTAPobj$pulses[pulseDelayPosition, ]
    preTAPobj$time = preTAPobj$time[pulseDelayPosition]
    preTAPobj$options$Name = paste0(TAPobj$options$Name, "pre")
    TAPexperiment[[paste0(TAPobj$options$Name, "pre")]] = preTAPobj

    TAPexperiment = TAPcodeV2::moments(TAPexperiment, preTAPobj$options$Name)
    preTAPobj = TAPexperiment[[preTAPobj$options$Name]]
    postPulses = TAPobj$pulses
    prePulses = TAPobj$pulses
    for(j in 1:dim(preTAPobj$pulses)[2]){
      normPreFlux = preTAPobj$pulses[, j] / preTAPobj$moments$M0[j]

      # tempMean = mean(normPreFlux * preTAPobj$time * max(preTAPobj$time)) * pi / 4
      # if( mean(normPreFlux * preTAPobj$time * max(preTAPobj$time)) < 0){
      #   tempMean = preTAPobj$time[which.max(normPreFlux)] * 3 * pi /4
      # }

      tempMean = preTAPobj$time[which.max(normPreFlux)] * 3 * pi /4
      basicShape = 3/2

      preFluxTail = density(rgamma(1000000, scale =  tempMean * 2/3, shape = basicShape), n = (length(TAPobj$time) - length(preTAPobj$time)), from = max(preTAPobj$time), to = max(TAPobj$time))$y
      prePulses[, j] = c(normPreFlux, preFluxTail* normPreFlux[length(normPreFlux)] / preFluxTail[1]) * preTAPobj$moments$M0[j]
      postPulses[, j] = TAPobj$pulses[, j] - prePulses[, j]
    }

    preTAPobj$pulses = prePulses
    preTAPobj$time = TAPobj$time
    postTAPobj = TAPobj
    postTAPobj$pulses = postPulses
    postTAPobj$options$Name = paste0(TAPobj$options$Name, "post")

    TAPexperiment[[preTAPobj$options$Name]] = preTAPobj
    TAPexperiment[[postTAPobj$options$Name]] = postTAPobj

    if(!is.null(TAPobj$moments)){
      TAPexperiment = TAPcodeV2::moments(TAPexperiment, preTAPobj$options$Name)
      TAPexperiment = TAPcodeV2::moments(TAPexperiment, postTAPobj$options$Name)
    }
  }
  return(TAPexperiment)
}



