#' Write Excel TAP file
#'
#' Write an Excel .xlsx of the original TDMS file.
#'
#' This function is based on R package rio.
#'
#' @param dataPath This is a string path to an .xlsx file.
#' @return A collection of TAP objects that describe the experiment performed in the reactor.
#' @examples
#'
#'
#' readTAP(path)
#' @export writeMoments

writeMoments = function(TAPexperiment, dataPath){
  sheetList = list()

  # reactorParams is manipulated and needs to be adjusted in the DF
  TAPexperiment$reactor$reactorDF$value = unlist(TAPexperiment$reactor$reactorParams,F,F)
  sheetList[["reactor"]] = (TAPexperiment[["reactor"]])$reactorDF
  sheetList[["secondaryInfo"]] = ""
  sheetList[["metaData"]] = ""

  TAPnames = names(TAPexperiment)
  for(i in 1:length(TAPexperiment)){
    if(TAPnames[i] == "reactor")
      next
    TAPobj = TAPexperiment[[i]]
    if(is.null(TAPobj$moments))
      next
    sheetList[[TAPnames[i]]] = TAPobj$moments
  }
  rio::export(sheetList, dataPath)

}

