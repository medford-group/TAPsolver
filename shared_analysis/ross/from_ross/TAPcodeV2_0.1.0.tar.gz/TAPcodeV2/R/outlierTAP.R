#' Outlier Removal
#'
#' Partition the pulse with an exponential decay from the mode.  Any points above or below 2 standard deviations are set to the median of the partition.
#'
#' @param TAPexperiment A TAP object of pulse values.
#' @param gasName Value
#' @return A vector of smoothed pulse values.
#' @examples
#'
#'
#'
#' @export outlierTAP

outlierTAP = function(TAPexperiment, gasName){
  for(i in 1:length(gasName)){
    TAPobj = TAPexperiment[[gasName[i]]]
    tempModes = TAPobj$time[apply(TAPobj$pulses, 2, robustMode)]

    for(j in 1:dim(TAPobj$pulses)[2]){
      tempPulse = TAPobj$pulses[,j]

      testSpacing = c(exp(seq(0,log(max(TAPobj$time) + 1),by = .05)) - 1 + tempModes[j], max(TAPobj$time))
      negativeTestSpacing = c(0,sort(abs(exp(seq(0,log(tempModes[j] + 1),by = .05)) - 1 - tempModes[j])))
      testSpacing = c(negativeTestSpacing[-length(negativeTestSpacing)], testSpacing)

      testIndex = rep(0,length(testSpacing))
      for(k in 1:length(testIndex)){
        testIndex[k] = which.min(abs(TAPobj$time - testSpacing[k]))
      }

      withoutOutliers = tempPulse
      for(k in 1:(length(testIndex)-1)){
        subPulse = tempPulse[testIndex[k]:testIndex[k+1]]
        subMedian = median(subPulse)
        subSD = sd(subPulse)
        subPulse[abs(subPulse) > (subMedian + 1.5 * subSD)] = subMedian
        withoutOutliers[testIndex[k]:testIndex[k+1]] = subPulse
      }
      TAPobj$pulses[,j] = withoutOutliers
    }
    TAPexperiment[[TAPobj$options$Name]] = TAPobj
  }
  return(TAPexperiment)
}
