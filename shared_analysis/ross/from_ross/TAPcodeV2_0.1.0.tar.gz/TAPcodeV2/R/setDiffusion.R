#' Set Diffusion Coefficient based on moments
#'
#' Blah
#'
#' blah
#'
#' @param TAPexperiment A set of pre-processing parameters based on the Y-Procedure
#' @param gasName Blah
#' @return Blah
#' @examples
#' data("pulseData")
#'
#'
#'@export setDiffusion

setDiffusion = function(TAPexperiment, gasName){
  TAPobj = TAPexperiment[[gasName]]
  inertObj = TAPexperiment[[TAPobj$options$inert]]
  reactorParams = TAPexperiment$reactor$reactorParams

  reactorLength = reactorParams$catalystBedLength + reactorParams$inertZone1Length + reactorParams$inertZone2Length

  if(is.null(inertObj$moments)){
    TAPexperiment[[TAPobj$options$inert]] = inertObj
    TAPexperiment = TAPcodeV2::moments(TAPexperiment, TAPobj$options$inert)
    inertObj = TAPexperiment[[TAPobj$options$inert]]
  }


  inertObj$options$diffusionCoef = mean(reactorParams$bedPorosity * reactorLength^2 * inertObj$moments$M0 / (2 * inertObj$moments$M1))
  TAPobj$options$diffusionCoef = inertObj$options$diffusionCoef * sqrt(inertObj$options$AMU / TAPobj$options$AMU)

  TAPexperiment[[gasName]] = TAPobj
  TAPexperiment[[TAPobj$options$inert]]
  return(TAPexperiment)
}
