#' Reactivities for TAP
#'
#' Reactivities for TAP
#'
#' blah
#'
#' @param TAPexperiment A set of pre-processing parameters based on the Y-Procedure
#' @param reactantGasName Blah
#' @param productGasName Blah
#' @return Blah
#' @examples
#' data("pulseData")
#'
#'
#'@export reactivities
reactivities = function(TAPexperiment, reactantGasName, productGasName){

  # Reactor parameters
  tempParams = TAPexperiment$reactor$reactorParams
  lengthOfInertZone = tempParams$inertZone1Length + tempParams$inertZone2Length
  reactorLength = tempParams$inertZone1Length + tempParams$inertZone2Length + tempParams$inertZone1Length + tempParams$catalystBedLength

  reactantObj = TAPexperiment[[reactantGasName]]
  if(is.null(reactantObj$moments)){
    TAPexperiment = TAPcodeV2::moments(TAPexperiment, reactantGasName)
    reactantObj = TAPexperiment[[reactantGasName]]
  }

  if(is.na(TAPobj$options$isProduct))
    TAPobj$options$isProduct = F

  inertObj = TAPexperiment[[reactantObj$options$inert]]
  if(is.null(inertObj$moments)){
    TAPexperiment = TAPcodeV2::moments(TAPexperiment, reactantObj$options$inert)
    inertObj = TAPexperiment[[reactantObj$options$inert]]
  }

  # Calculating the residence time for the inert and reactant
  inertObj$moments$resTime = tempParams$bedPorosity * lengthOfInertZone^2 / (2 * inertObj$moments$diffusion)
  reactantObj$moments$diffusion = inertObj$moments$diffusion * sqrt(inertObj$options$AMU / reactantObj$options$AMU)
  reactantObj$moments$resTime = tempParams$catalystBedLength * lengthOfInertZone / ( 2 * reactantObj$moments$diffusion)

  # Calculating the reactivities for the reactant
  reactantObj$moments$R0 = -1 / reactantObj$moments$resTime + 1 / (reactantObj$moments$resTime * reactantObj$moments$M0norm)
  reactantObj$moments$R1 = -2 * inertObj$moments$resTime / (3 * reactantObj$moments$resTime) - inertObj$moments$resTime /
    (3 * reactantObj$moments$resTime * reactantObj$moments$M0norm) + reactantObj$moments$M1norm / (reactantObj$moments$resTime * reactantObj$moments$M0norm^2)
  reactantObj$moments$R2 = 4 * inertObj$moments$resTime^2/(45 * reactantObj$moments$resTime) + 7 * inertObj$moments$resTime^2 / (90 * reactantObj$moments$resTime * reactantObj$moments$M0norm) -
    inertObj$moments$resTime * reactantObj$moments$M1norm / (3 * reactantObj$moments$resTime * reactantObj$moments$M0norm^2) - reactantObj$moments$M2norm /
    (2 * reactantObj$moments$resTime * reactantObj$moments$M0norm^2) + reactantObj$moments$M1norm^2 / (reactantObj$moments$resTime * reactantObj$moments$M0norm^3)

  TAPexperiment[[reactantGasName]] = reactantObj
  TAPexperiment[[reactantObj$options$inert]] = inertObj

  if(length(productGasName) == 0)
    return(TAPexperiment)

  for(i in 1:length(productGasName)){
    productObj = TAPexperiment[[productGasName[i]]]
    if(is.null(productObj$moments)){
      TAPexperiment = TAPcodeV2::moments(TAPexperiment, productGasName[i])
      productObj = TAPexperiment[[productGasName[i]]]
    }
    inertObj$moments$diffusion * sqrt(inertObj$options$AMU / productObj$options$AMU)
    productObj$moments$resTime = tempParams$catalystBedLength * lengthOfInertZone / ( 2 * productObj$moments$diffusion)
    productObj$moments$R0 = productObj$moments$M0norm / (productObj$moments$resTime * reactantObj$moments$M0norm)
    productObj$moments$R1 = productObj$moments$R0 * (inertObj$moments$resTime / 12 * (8 * reactantObj$moments$M0norm + 3 + 9 * reactantObj$moments$diffusion / productObj$moments$diffusion) +
                                     productObj$moments$resTime * reactantObj$moments$M0norm * reactantObj$moments$R1 - productObj$moments$M1M0)
    productObj$moments$R2 = productObj$moments$R0 / 2 * (productObj$moments$M2M0 - 19 * reactantObj$moments$diffusion^2 * inertObj$moments$resTime / (16 * productObj$moments$diffusion) *
                                         (productObj$moments$R0 * (inertObj$moments$resTime * (3 + 8 * reactantObj$moments$M0norm) + 12 * reactantObj$moments$M0norm *
                                                           reactantObj$moments$R1 * productObj$moments$resTime) - 12 * productObj$moments$R1) +
                                         productObj$moments$R1 / (6 * productObj$moments$R0) * ((3 + 8 * reactantObj$moments$M0norm) * inertObj$moments$resTime + 12 * reactantObj$moments$M0norm *
                                                                                reactantObj$moments$R1 * productObj$moments$resTime) - inertObj$moments$resTime^2 *
                                         (5 / 48 + reactantObj$moments$M0norm / 45 * (23 + 40 * reactantObj$moments$M0norm)) -
                                         reactantObj$moments$M0norm / 6 * (3 + 16 * reactantObj$moments$M0norm) * reactantObj$moments$R1 * productObj$moments$resTime * inertObj$moments$resTime -
                                         2 * reactantObj$moments$M0norm * productObj$moments$resTime * (reactantObj$moments$M0norm * reactantObj$moments$R1^2 * productObj$moments$resTime - reactantObj$moments$R2))
    TAPexperiment[[productGasName[i]]] = productObj
  }

  return(TAPexperiment)
}
