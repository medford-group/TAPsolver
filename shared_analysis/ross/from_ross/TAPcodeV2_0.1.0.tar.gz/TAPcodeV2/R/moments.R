#' Moments of an TAP Pulse
#'
#' Function for determining the moments of a pulse.
#'
#'The \eqn{n^{th}} moment is defined by:
#'\deqn{ \int t^n pulse(t) dt}
#'
#'
#'
#' @param TAPobj A TAP pulse or series of pulses.
#' @return A vector of moments based on the pulse.
#' @examples
#' data("pulseData")
#'
#' inertPulse = pulseData$`40AMU`$pulses[,33:35]
#' timeVector = pulseData$`40AMU`$time
#'
#'
#' moments(inertPulse ,timeVector,2)
#'
#'@export moments
moments = function(TAPexperiment, gasName){

  tempParams = TAPexperiment$reactor$reactorParams
  lengthOfInertZone = tempParams$inertZone1Length + tempParams$inertZone2Length
  reactorLength = lengthOfInertZone + tempParams$catalystBedLength

  for(i in 1:length(gasName)){
    TAPobj = TAPexperiment[[gasName[i]]]
    # inertObj = TAPexperiment[[TAPobj$options$inert]]
    #
    # timeMinPos = which.min(abs(inertObj$time - inertObj$options$timeStart))
    # timeMaxPos = which.min(abs(inertObj$time - inertObj$options$timeEnd))
    # baseMinPos = which.min(abs(inertObj$time - inertObj$options$baselineStart))
    # baseMaxPos = which.min(abs(inertObj$time - inertObj$options$baselineEnd))
    # tempTime = inertObj$time[timeMinPos:timeMaxPos]
    #
    # tempMat1 = matrix(rep(inertObj$time, dim(inertObj$pulses)[2]), length(inertObj$time), dim(inertObj$pulses)[2])
    # tempMat2 = matrix(rep(inertObj$time^2, dim(inertObj$pulses)[2]), length(inertObj$time), dim(inertObj$pulses)[2])
    #
    # momentsObj = data.frame("max" = apply(inertObj$pulses, 2, max))
    # momentsObj$baselineShift = apply(inertObj$pulses[(baseMinPos:baseMaxPos), ], 2, mean)
    # momentsObj$M0 = apply(inertObj$pulses[timeMinPos:timeMaxPos, ], 2, pracma::trapz) * max(tempTime) / length(tempTime)
    # momentsObj$M1 = apply(inertObj$pulses[timeMinPos:timeMaxPos, ] * tempMat1, 2, pracma::trapz) * max(tempTime) / length(tempTime)# tempM1 #apply(sweep(inertObj$pulses[timeMinPos:timeMaxPos, ], 2, inertObj$time[timeMinPos:timeMaxPos]^1, FUN = "*") , 2, pracma::trapz) * max(inertObj$time[timeMinPos:timeMaxPos]) / length(inertObj$time[timeMinPos:timeMaxPos])
    # momentsObj$M2 = apply(inertObj$pulses[timeMinPos:timeMaxPos, ] * tempMat2, 2, pracma::trapz) * max(tempTime) / length(tempTime)#tempM2 #apply(sweep(inertObj$pulses[timeMinPos:timeMaxPos, ], 2, inertObj$time[timeMinPos:timeMaxPos]^2, FUN = "*") , 2, pracma::trapz) * max(inertObj$time[timeMinPos:timeMaxPos]) / length(inertObj$time[timeMinPos:timeMaxPos])
    # momentsObj$M0norm = momentsObj$M0 / momentsObj$M0
    # momentsObj$M1norm = momentsObj$M1 / momentsObj$M0
    # momentsObj$M2norm = momentsObj$M2 / momentsObj$M0
    # momentsObj$M1M0 = momentsObj$M1 / momentsObj$M0
    # momentsObj$M2M0 = momentsObj$M2 / momentsObj$M0
    # momentsObj$mode = tempTime[apply(TAPobj$pulses[timeMinPos:timeMaxPos,], 2, which.max)]
    # momentsObj$knudsenRatio = momentsObj$M1norm / momentsObj$mode
    #
    # if(inertObj$options$diffusionCoef != 0){
    #    momentsObj$diffusion = rep(inertObj$options$diffusionCoef, length(momentsObj$M0))
    # }else{
    #   momentsObj$diffusion = tempParams$bedPorosity * reactorLength^2 * momentsObj$M0 / (2 * momentsObj$M1)
    # }
    # inertObj$moments = momentsObj
    # inertObj$moments$temperature = inertObj$temperature
      #inertObj$options$diffusionCoef = mean(momentsObj$diffusion)

    timeMinPos = which.min(abs(TAPobj$time - TAPobj$options$timeStart))
    timeMaxPos = which.min(abs(TAPobj$time - TAPobj$options$timeEnd))
    baseMinPos = which.min(abs(TAPobj$time - TAPobj$options$baselineStart))
    baseMaxPos = which.min(abs(TAPobj$time - TAPobj$options$baselineEnd))
    tempTime = TAPobj$time[timeMinPos:timeMaxPos]

    tempMat1 = matrix(rep(TAPobj$time, dim(TAPobj$pulses)[2]), length(TAPobj$time), dim(TAPobj$pulses)[2])
    tempMat2 = matrix(rep(TAPobj$time^2, dim(TAPobj$pulses)[2]), length(TAPobj$time), dim(TAPobj$pulses)[2])


    #momentsObj = list()
    momentsObj = data.frame("max" = apply(TAPobj$pulses, 2, max))
    momentsObj$baselineShift = apply(TAPobj$pulses[(baseMinPos:baseMaxPos), ], 2, mean)
    momentsObj$M0 = apply(TAPobj$pulses[timeMinPos:timeMaxPos, ], 2, pracma::trapz) * max(tempTime) / length(tempTime)
    momentsObj$M1 = apply((TAPobj$pulses * tempMat1)[timeMinPos:timeMaxPos, ], 2, pracma::trapz) * max(tempTime) / length(tempTime) #apply(sweep(TAPobj$pulses[timeMinPos:timeMaxPos, ], 2, TAPobj$time[timeMinPos:timeMaxPos]^1, FUN = "*") , 2, pracma::trapz) * max(TAPobj$time[timeMinPos:timeMaxPos]) / length(TAPobj$time[timeMinPos:timeMaxPos])
    momentsObj$M2 = apply((TAPobj$pulses * tempMat2)[timeMinPos:timeMaxPos, ], 2, pracma::trapz) * max(tempTime) / length(tempTime) #apply(sweep(TAPobj$pulses[timeMinPos:timeMaxPos, ], 2, TAPobj$time[timeMinPos:timeMaxPos]^2, FUN = "*") , 2, pracma::trapz) * max(TAPobj$time[timeMinPos:timeMaxPos]) / length(TAPobj$time[timeMinPos:timeMaxPos])
    momentsObj$M0norm = momentsObj$M0 / momentsObj$M0
    momentsObj$M1norm = momentsObj$M1 / momentsObj$M0
    momentsObj$M2norm = momentsObj$M2 / momentsObj$M0
    momentsObj$M1M0 = momentsObj$M1 / momentsObj$M0
    momentsObj$M2M0 = momentsObj$M2 / momentsObj$M0
    momentsObj$mode = tempTime[apply(TAPobj$pulses[timeMinPos:timeMaxPos,], 2, which.max)] #tempTime[apply(TAPobj$pulses[timeMinPos:timeMaxPos,], 2, TAPcodeV2::robustMode)]
    momentsObj$knudsenRatio = momentsObj$M1norm / momentsObj$mode

    if(TAPobj$options$diffusionCoef != 0){
      momentsObj$diffusion = rep(TAPobj$options$diffusionCoef, length(momentsObj$M0))
    }else{
      momentsObj$diffusion = tempParams$bedPorosity * reactorLength^2 * momentsObj$M0 / (2 * momentsObj$M1)
    }

    TAPobj$moments = momentsObj
    #TAPobj$options$diffusionCoef = mean(momentsObj$diffusion)
    TAPobj$moments$temperature = TAPobj$temperature

    TAPexperiment[[TAPobj$options$Name]] = TAPobj
    # if(TAPobj$options$Name != TAPobj$options$inert){
    #   TAPexperiment[[TAPobj$options$inert]] = inertObj
    # }

  }


  return(TAPexperiment)
}
