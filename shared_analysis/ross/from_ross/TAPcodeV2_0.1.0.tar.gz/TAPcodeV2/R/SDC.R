#' Standard Diffusion Curve
#'
#' Create a standard diffusion curve based on the inert gas to determine if the procedure is under the Knudsen diffusion regime.
#'
#'
#' \deqn{ \frac{1}{2} \pi M0/M1 \sum_{j=0}^{2000} (-1)^j (2j + 1) exp(-0.5 \pi^2 (j + 0.5)^2 M0/M1 )}
#'
#' @param diffusion Estimated diffusion coefficient.
#' @param timeVector A vector of time values.
#' @param L The length of the reactor.
#' @param bedPorosity Bed Porosity of the reactor.
#' @return A data frame of the pulse and the standard diffusion values based on time.
#' @examples
#'
#'
#' @references
#' See "Temporal analysis of products: basic principles, applications, and theory." Journal of Catalysis, 2003
#'
#' @seealso
#' \url{http://www.sciencedirect.com/science/article/pii/S0021951702001094}
#' @export SDC
SDC = function(TAPexperiment, gasName){

  for(i in 1:length(gasName)){
    TAPobj = TAPexperiment[[gasName[i]]]

    if(is.null(TAPobj$moments)){
      TAPexperiment = TAPcodeV2::moments(TAPexperiment, TAPobj$options$Name)
      TAPobj = TAPexperiment[[TAPobj$options$Name]]
    }

    timeMinPos = which.min(abs(TAPobj$time - TAPobj$options$timeStart))
    timeMaxPos = which.min(abs(TAPobj$time - TAPobj$options$timeEnd))
    if(timeMinPos != 1){
      timePre = rep(0,timeMinPos)[-1]
    }
    if(timeMaxPos != length(TAPobj$time)){
      timePost = rep(0, (length(TAPobj$time) - timeMaxPos))
    }
    timeVector = TAPobj$time[timeMinPos:timeMaxPos]
    timeVector = timeVector - min(timeVector)
    timeVector = timeVector[-1]
    iVals = 1:(length(timeVector))

    reactorLength = TAPexperiment$reactor$reactorParams$inertZone1Length + TAPexperiment$reactor$reactorParams$inertZone2Length + TAPexperiment$reactor$reactorParams$catalystBedLength
    nTerms = 2000
    jTerms = 0: nTerms
    negativeIteration = rep(1,(nTerms + 1))
    negativeIteration[jTerms %% 2 == 0] = -1
    negativeIteration = negativeIteration * -1
    negWithJ = t(as.matrix(negativeIteration * (2 * jTerms + 1)))

    for(j in 1:length(TAPobj$moments$diffusion)){
      mRatio = TAPexperiment$reactor$reactorParams$bedPorosity * reactorLength^2 / (2 * TAPobj$moments$diffusion[j] )

      exponentTerms = as.matrix(-.5 * pi^2 * (jTerms + .5)^2 / mRatio)
      exponentWithTime = negWithJ %*% exp((exponentTerms) %*% t(as.matrix(timeVector)))
      sdc = pi * as.numeric(exponentWithTime) / (mRatio * 2)
      sdc = c(sdc,0)

      if(timeMinPos != 1){
        sdc = c(timePre, sdc)
      }
      if(timeMaxPos != length(TAPobj$time)){
        sdc = c(sdc, timePost)
      }
      TAPobj$pulses[,j] = sdc
    }


    TAPobj$options$Name = paste0(TAPobj$options$Name, "SDC")
    TAPexperiment[[TAPobj$options$Name]] = TAPobj
  }

  # if(!is.numeric(diffusion)){

  # }else{
  #   TAPobj$options$Name = paste0(TAPobj$options$Name, "SDC", format(diffusion, scientific = T,digits = 3))
  # }
  # TAPobj$pulses = data.frame("sdc" = sdc)
  # names(TAPobj$pulses) = TAPobj$options$Name

  return(TAPexperiment)
}
