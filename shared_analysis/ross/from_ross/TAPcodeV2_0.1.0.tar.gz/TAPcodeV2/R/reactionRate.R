#' Reaction Rate
#'
#' Blah
#'
#' blah
#'
#' @param TAPexperiment A set of pre-processing parameters based on the Y-Procedure
#' @param gasName Blah
#' @param method Blah
#' @return Blah
#' @examples
#' data("pulseData")
#'
#'
#'@export reactionRate
#'
reactionRate = function(TAPexperiment, gasName, method = "y"){

  for(i in 1:length(gasName)){
    if(is.null(TAPexperiment[[gasName[i]]]$reactorLength)){
      TAPexperiment = initYproc(TAPexperiment, gasName[i], method)
    }
    TAPobj = TAPexperiment[[gasName[i]]]
    TAPobj$options$Name = paste0(TAPobj$options$Name, "rate")

    if(is.na(TAPobj$options$isProduct))
      TAPobj$options$isProduct = F

    if(!(TAPobj$options$isProduct)){
      TAPobj$pulses = TAPexperiment[[TAPobj$options$inert]]$pulses - TAPobj$pulses
      TAPexperiment[[TAPobj$options$Name]] = TAPobj
      TAPexperiment = moments(TAPexperiment, TAPobj$options$Name)
      TAPobj = TAPexperiment[[TAPobj$options$Name]]
    }

    if(method == "y"){
      for(j in 1:dim(TAPobj$pulses)[2]){
        tempPulse = TAPobj$pulses[TAPobj$timeRange, j]

        result = Re(fft(fft(tempPulse) * TAPobj$rateScalar, inverse = T)) * TAPobj$reactionRateScalar[j]
        if(length(tempPulse) != dim(TAPobj$pulses)[1]){
          trailingMedian = rep(median(result[round(.9*length(result)):length(result)]), dim(TAPobj$pulses)[1] - length(result))
          result = c(result, trailingMedian)
        }
        TAPobj$pulses[, j] = result
      }
    }else{
      rateScalar = 1 - 1.5 * TAPobj$inertZoneRatio^2
      basicShape =  3 / 2

      for(j in 1:dim(TAPobj$pulses)[2]){
        tempPulse = TAPobj$pulses[TAPobj$timeRange, j] / TAPobj$moments$M0[j]

        tempMean = mean(tempPulse * TAPobj$currentTime * TAPobj$options$timeEnd) * pi / 4
        if((mean(tempPulse * TAPobj$currentTime * TAPobj$options$timeEnd) < 0)){
          # use median if mean is below zero due to noise
          tempMean = TAPobj$currentTime[TAPcodeV2::robustMode(tempPulse)] * 3 * pi / 4
        }
        pulseGamma = pgamma(TAPobj$currentTime, shape = basicShape, scale = tempMean * 2/3)
        gasGamma = pgamma(TAPobj$currentTime, shape = rateScalar * basicShape, scale = tempMean * 2/3)
        gasRatio = gasGamma / pulseGamma

        result = c(0, diff(cumsum(tempPulse) * gasRatio)) * TAPobj$moments$M0[j] * TAPobj$reactionRateScalar[j]
        result[is.na(result)] = 0

        if(length(tempPulse) != dim(TAPobj$pulses)[1]){
          trailingMedian = rep(median(result[round(.9*length(result)):length(result)]), dim(TAPobj$pulses)[1] - length(result))
          result = c(result, trailingMedian)
        }
        TAPobj$pulses[, j] = result
      }
    }

    TAPexperiment[[TAPobj$options$Name]] = TAPobj
  }
  return(TAPexperiment)
}
